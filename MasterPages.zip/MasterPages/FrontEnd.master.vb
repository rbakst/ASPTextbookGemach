﻿
Partial Class MasterPages_FrontEnd
    Inherits System.Web.UI.MasterPage
End Class

